package java_homework_20240120;
// 1. 구매정보와 구매 정보에 대한 결제 정보를 같이 출력하고 싶다. 
// 그런데 구매 정보와 결제정보는 별도의 클래스로 만들어져 있다.
// 구매정보 : 구매자(purchaseName), 구매금액:totalPrice
// 결제정보 : 승인번호(confirmNum), 결제일: paymentDate, 카드번호(cardNum)
public class PurchaseInfo {
	String purchaseName; // 구매자 이름
	int totalPrice; // 총 구매 금액
	// 구매자 이름을 매개 변수로 받는 생성자
	public PurchaseInfo(String purchaseName) {
		super();
		this.purchaseName = purchaseName;
	}
	// 고객이 구매한 경우를 구현한 메서드
	public void purchase(int totalPrice) {
		this.totalPrice += totalPrice;
	}
	// 구매 정보 출력
	public void showInfo() {
		System.out.println(purchaseName + "님께서 구매하신 총 금액은 "
				+ totalPrice + "원 입니다.");
	}
}
