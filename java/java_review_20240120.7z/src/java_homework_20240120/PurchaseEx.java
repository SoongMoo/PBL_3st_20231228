package java_homework_20240120;

public class PurchaseEx {
	public static void main(String[] args) {
		// 뽀구라는 이름의 구매자 생성
		PurchaseInfo p1 = new PurchaseInfo("뽀구");
		// 결제 정보 생성
		ConfirmInfo c1 = new ConfirmInfo("12345678", "2024-01-20", "99998888");
		p1.purchase(2000);
		p1.showInfo();
		c1.showInfo();
	}
}
