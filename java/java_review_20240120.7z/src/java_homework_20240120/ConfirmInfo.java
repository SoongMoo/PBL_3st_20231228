package java_homework_20240120;

public class ConfirmInfo {
	String confirmNum; // 승인번호
	String paymentDate; // 결제일
	String cardNum; // 카드번호
	// 결제 정보를 매개 변수로 받는 생성자
	public ConfirmInfo(String confirmNum, String paymentDate, String cardNum) {
		super();
		this.confirmNum = confirmNum;
		this.paymentDate = paymentDate;
		this.cardNum = cardNum;
	}
	// 결제 정보 출력
	public void showInfo() {
		System.out.println("승인번호: " + confirmNum +
							" 결제일: " + paymentDate +
							" 카드번호: " + cardNum);
	}
}
