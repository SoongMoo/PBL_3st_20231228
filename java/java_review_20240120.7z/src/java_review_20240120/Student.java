package java_review_20240120;

public class Student {
	public String studentName; // 학생 이름
	public int grade; // 학년
	public int money; // 학생이 가지고 있는 돈
	// 학생 이름과 가진 돈을 매개 변수로 받는 생성자
	public Student(String studentName, int money) {
		super();
		this.studentName = studentName;
		this.money = money;
	}
	// 학생이 버스를 타면 1,000원을 지불하는 기능을 구현한 메서드
	public void takeBus(Bus bus) {
		bus.take(1000);
		this.money -= 1000;
	}
	// 학생이 지하철을 타면 1,500원을 지불하는 기능을 구현한 메서드
	public void takeSubway(Subway subway) {
		subway.take(1500);
		this.money -= 1500;
	}
	public void takeTaxi(Taxi taxi) {
		taxi.take(10000);
		this.money -= 10000;
	}
	// 학생의 현재 정보를 출력하는 메서드
	public void showInfo() {
		System.out.println(studentName + "님의 남은 잔액은 " + money + "원 입니다.");
	}
	
}
