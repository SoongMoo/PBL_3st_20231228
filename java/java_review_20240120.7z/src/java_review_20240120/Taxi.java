package java_review_20240120;

public class Taxi {
	String taxiNum;
	int passengerCount;
	int money;
	// 택시 번호를 매개 변수로 받는 생성자
	public Taxi(String taxiNum) {
		super();
		this.taxiNum = taxiNum;
	}
	// 승객이 택시를 탄 경우를 구현한 메서드
	public void take(int money) {
		this.money += money;
		passengerCount++;
	}
	// 택시 정보를 출력하는 메서드
	public void showInfo() {
		System.out.println(taxiNum + "의 승객은 " + passengerCount + "명이고, 수입은 "
				+ money + "원 입니다.");
	}
}
