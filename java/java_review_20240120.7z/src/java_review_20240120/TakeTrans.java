package java_review_20240120;

public class TakeTrans {

	public static void main(String[] args) {
		// 학생 두명 생성
		Student studentMax = new Student("Max", 5000);
		Student studentLeo = new Student("Leo", 10000);
		Student studentEdward = new Student("Edward", 10000);
		
		Bus bus100 = new Bus(100); // 노선 번호가 100번인 버스 생성
		studentMax.takeBus(bus100); // Max가 100번 버스를 탑승
		studentMax.showInfo(); // Max 정보 출력
		bus100.showInfo(); // 100번 버스 정보 출력
		
		Subway subwayGreen = new Subway("2호선"); // 노선 번호가 2호선인 지하철 생성
		studentLeo.takeSubway(subwayGreen); // Leo가 지하철 2호선을 탑승
		studentLeo.showInfo(); // Leo 정보 출력
		subwayGreen.showInfo(); // 지하철 2호선 정보 출력
		
		// 나 혼자 코딩! 택시 타는 과정 구현하기
		Taxi taxiKakao = new Taxi("카카오택시");
		studentEdward.takeTaxi(taxiKakao);
		studentEdward.showInfo();
		taxiKakao.showInfo();
	}

}
