package java_review_20240120;

public class Bus {
	int busNumber; // 버스 번호
	int passengerCount; // 승객 수
	int money; // 버스 수입
	// 버스 번호를 매개변수로 받는 생성자
	public Bus(int busNumber) {
		super();
		this.busNumber = busNumber;
	}
	// 승객이 버스에 탄 경우를 구현한 메서드
	public void take(int money) {
		this.money += money; // 버스 수입 증가
		passengerCount++; // 승객 수 증가
	}
	// 버스 정보를 출력하는 메서드
	public void showInfo() {
		System.out.println("버스 " + busNumber + "번의 승객은 " + passengerCount + "명이고, 수입은 "
				+ money + "원 입니다.");
	}
	// 버스 클래스의 멤버 변수로는 버스 번호, 승객 수, 버스가 받은 요금 총액이 있습니다. 
	// take() 메서드에서 승객 한 명이 버스를 탄 경우를 구현합니다.
	// 승객이 요금을 지불합니다. 요금을 매개변수로 받고(거스름돈은 생략) 요금이 들어오면 버스 수입이 증가하고 승객 수도 증가합니다.
	// 8행 Bus(int busNumber) 생성자에서는 버스 번호를 매개 변수로 받아 버스가 생성될 때 버스 번호를 초기화 합니다.
	// 마지막으로 showInfo() 메서드에서 버스 번호와 버스를 탄 승객 수 그리고 버스 수입을 문자열로 연결하여 출력합니다.
}
