package java_review_20240120;

public class Subway {
	String lineNumber; // 지하철 노선
	int passengerCount; // 승객 수
	int money; // 수입액
	// 지하철 노선 번호를 매개변수로 받는 생성자
	public Subway(String lineNumber) {
		super();
		this.lineNumber = lineNumber;
	}
	// 승객이 지하철에 탄 경우를 구현한 메서드
	public void take(int money) {
		this.money += money;
		passengerCount++;
	}
	// 지하철 정보 출력하는 메서드
	public void showInfo() {
		System.out.println(lineNumber + "의 승객은 " + passengerCount + "명이고, 수입은 "
				+ money + "원 입니다.");
	}
	/*
	 * Subway(String lineNumber) 생성자가 지하철 몇 호선인지를 매개 변수로 받아 Subway 클래스를 생성합니다.
	 * take() 메서드는 승객이 탄 경우에 발생하는 일을 구현합니다.
	 * 지하철 수입이 증가하고 지하철 승객 수가 한 명 증가합니다. showInfo() 메서드는 지하철 노선, 승객 수, 지하철 수입 금액을 문자열로 출력합니다.
	 */
}
