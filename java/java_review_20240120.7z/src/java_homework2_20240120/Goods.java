package java_homework2_20240120;
// 2. 상품정보를 입력하는데  상품번호는 10000번부터 1씩 증가하는 값을 가져야한다. 
// 숫자를 이용하지말고 상품번호를 부여하자
// 상품정보 ㅣ  상품번호 : goodsNum ,  상품이름 : goodsName , 가격 :  goodsPrice
public class Goods {
	static int goodsNum = 10000;
	String goodsName;
	int goodsPrice;
	// 상품 이름과 가격을 매개 변수로 하는 생성자
	public Goods(String goodsName, int goodsPrice) {
		super();
		this.goodsName = goodsName;
		this.goodsPrice = goodsPrice;
	}
	// 상품 정보 출력
	public void showInfo() {
		System.out.println("[상품번호]: " + goodsNum +
							" [상품이름]: " + goodsName +
							" [상품가격]: " + goodsPrice + "루피");
	}
}
