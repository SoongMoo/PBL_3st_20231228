package java_homework2_20240120;

public class GoodsEx {

	public static void main(String[] args) {
		Goods goods1 = new Goods("하이랄 쌀", 3);
		goods1.showInfo();
		Goods.goodsNum++;
		
		Goods goods2 = new Goods("하이랄 토마토",1);
		goods2.showInfo();
		Goods.goodsNum++;
	
		Goods goods3 = new Goods("고론의 향신료", 4);
		goods3.showInfo();
		Goods.goodsNum++;
	}
}
