package java_homework3_20240120;
// 3. 스타크레프트에서 게임아이템의 이름과 아이템의 체력이 있을 때  
// 게임유저가 아이템을 사용할 때마다 체력이 10씩 감소 한다.
// 사용할 때마다 유저명과 아이템명 그리고 체력이 출력되게 하시오. 
// 클래스명은 StarCraft, 게임유저는 User라는 클래스로 되어 있다.
// 옵션을 획득하면 체력이 10씩 증가하도록도 하세요.
public class StarCraft {
	String itemName;
	int itemEnergy;
	// 아이템 이름과 에너지를 매개 변수로 하는 생성자
	public StarCraft(String itemName, int itemEnergy) {
		super();
		this.itemName = itemName;
		this.itemEnergy = itemEnergy;
	}
	// 유저가 아이템을 사용했을때를 구현한 메서드
	public void useItem(User user) {
		if(itemEnergy > 0) { // 에너지가 0보다 커야 사용 가능
			this.itemEnergy -= 10;
			System.out.println(user.userName + "님께서 " + itemName + " 사용 " + "현재 에너지: " + itemEnergy);
		} else {
			System.out.println("에너지가 부족합니다!");
		}
	}
	// 유저가 아이템을 획득했을때를 구현한 메서드
	public void getItem(User user) {
		this.itemEnergy += 10;
		System.out.println(user.userName + "님께서 " + itemName + " 획득 " + "현재 에너지: " + itemEnergy);
	}
}
