package java_homework3_20240120;

public class MainGame {

	public static void main(String[] args) {
		User user1 = new User("마린"); // 마린 유저 생성
		StarCraft sc1 = new StarCraft("스팀팩", 50); // 아이템 스팀팩, 초기 에너지 50 설정
		
		sc1.useItem(user1); // user1이 sc1 아이템 사용
		sc1.getItem(user1); // user1이 sc1 아이템 획득
		sc1.useItem(user1); // user1이 sc1 아이템 사용
		
		User user2 = new User("하이템플러"); // 하이템플러 유저 생성
		StarCraft sc2 = new StarCraft("사이오닉 스톰", 100); // 아이템 사이오닉 스톰, 초기 에너지 100 설정
		
		for(int i=1; i<=10; i++) {
			sc2.useItem(user2); // user2가 sc2 아이템 10번 사용
		}
		// 에너지 0일 경우 사용안되는 것 확인
		sc2.useItem(user2);
		
		sc2.getItem(user2); // user2가 아이템을 획득, 에너지 10 증가
		sc2.useItem(user2); // 사이오닉 스톰 아이템이 다시 사용 되는것을 확인
	}

}
