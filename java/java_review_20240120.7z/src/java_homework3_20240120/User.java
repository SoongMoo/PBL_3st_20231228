package java_homework3_20240120;

public class User {
	public String userName; // 유저 이름
	// 유저 이름을 매개 변수로 받는 생성자
	public User(String userName) {
		super();
		this.userName = userName;
	}
}
