package homework_array3;
import java.util.Random;

public class Mineral {
	Random rd = new Random();
	int Mineral;
	int mineralNumber;

	public int getMineralNumber() {
		return mineralNumber;
	}

	public void setMineralNumber(int mineralNumber) {
		this.mineralNumber = mineralNumber;
	}

	public int getMineral() {
		return Mineral;
	}

	public void setMineral(int mineralNumber) { 
		Mineral = mineralNumber * (rd.nextInt(15)+5);
		System.out.println("미네랄 "+mineralNumber+"을 캐내어 금액 총" +Mineral+" 을 회복했습니다.");
	}
	
	

}
