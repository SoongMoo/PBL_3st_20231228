package homework_array3;

public class StarCraftUnit {
	// 유닛을 뽑을 수 있는 총 금액이 있는데, 유닛을 뽑을때마다 총 금액 10이 감소함
	// 미네랄을 캘때 마다 금액 10이 증가함
	int cost;
	String unitName;
	
	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}
	
}
