package homework_array3;

public class GameStart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 스타크래프트에는 미네랄이라고 불리는 유저가 사용가능한 게임재화가 존재함
		// 유닛을 뽑을 수 미네랄 가격이 있는데, 유닛을 뽑을때마다 감소함
		// 미네랄은 유저가 게임중 광석처럼 캘수가 있으며 캘때 마다 금액 5~15가 랜덤적으로 증가함
		//문제와는 살짝 다르게 Mineral 이라는 클래스를 만들어 옵션을 얻어 체력을 회복한다고 했던 것을 표현하였음
		//즉 미네랄 = 체력
		// 유저가 미네랄을 캔 갯수에 랜덤값(5~15)을 곱하여 얻을수 있게 하였음
		// 총 미네랄이 늘어나는 방식으로 재화를 회복
		StarCraftUnit juggling = new StarCraftUnit();
		juggling.setUnitName("저글링");	//아이템 이름
		juggling.setCost(10);	//아이템 사용시 감소할 미네랄(체력)
		
		StarCraftUser kiyoung = new StarCraftUser();
		kiyoung.setUserName("오기영");	//유저이름 설정
		kiyoung.setTotalMineral(100);	//유저 총 미네랄(총 체력) 설정
		kiyoung.setStarcraftUnit(juggling);
		kiyoung.useUnit(juggling);	//유닛 뽑기(아이템 사용)
		
		Mineral mineral = new Mineral();	
	    mineral.setMineralNumber(3);	//유저가 얻을 미네랄 갯수 설정(유저가 얻을 옵션 갯수 설정)
		mineral.setMineral(mineral.getMineralNumber());		//미네랄 갯수만큼 5~15사이의 랜덤값 회복(옵션 갯수 만큼)
	
		
		
		
		
		
		


	}

}
