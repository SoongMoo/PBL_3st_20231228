package homework_array3;

public class StarCraftUser {
	// 유닛을 뽑을 수 있는 총 금액이 있는데, 유닛을 뽑을때마다 총 금액 10이 감소함
	// 미네랄을 캘때 마다 금액 10이 증가함
	// 스타크래프트에서는 미네랄이라는 재화를 얻어서 저글링,마린과 같은 유닛을 뽑을수있음
	String userName;
	int totalMineral;
	StarCraftUnit starcraftUnit;
	Mineral mineral;

	public void useUnit(StarCraftUnit starcraftUnit) {
		setTotalMineral(totalMineral-starcraftUnit.getCost());
		System.out.println(userName+"님이 "+starcraftUnit.getUnitName()+"을 생산하여 미네랄 "+starcraftUnit.getCost()+
				"을 사용해 총"+getTotalMineral()+"미네랄 남았습니다.");
		
	}
	
	public void checkMineral() {
		totalMineral+=mineral.getMineral();
		System.out.println("현재 소지하고 있는 총 미네랄은 "+totalMineral+"입니다.");
	}
	
	
	
	public Mineral getMineral() {
		return mineral;
	}

	public void setMineral(Mineral mineral) {
		this.mineral = mineral;
	}
	
	public StarCraftUnit getStarcraftUnit() {
		return starcraftUnit;
	}
	public void setStarcraftUnit(StarCraftUnit starcraftUnit) {
		this.starcraftUnit = starcraftUnit;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getTotalMineral() {
		return totalMineral;
	}
	public void setTotalMineral(int totalMineral) {
		this.totalMineral = totalMineral;
	}
	
	
	
	
	
	
	

}
