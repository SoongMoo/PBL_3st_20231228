package homework_array2;

public class GoodsPlus {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Goods goods1 = new Goods();
		goods1.setGoodsNum(goods1.specialNum++);
		goods1.setGoodsName("세탁기");
		goods1.setGoodsPrice("2만원");
		System.out.println(goods1.getGoodsNum());
		System.out.println(goods1.getGoodsName());
		System.out.println(goods1.getGoodsPrice());
		
		Goods goods2 = new Goods();
		goods2.setGoodsNum(goods1.specialNum++);
		goods2.setGoodsName("청소기");
		goods2.setGoodsPrice("3만원");
		System.out.println(goods2.getGoodsNum());
		System.out.println(goods2.getGoodsName());
		System.out.println(goods2.getGoodsPrice());

	}

}
