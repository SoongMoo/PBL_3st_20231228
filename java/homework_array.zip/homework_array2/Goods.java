package homework_array2;

public class Goods {
	static int specialNum;
	
	int goodsNum;
	String goodsName;
	String goodsPrice;
	
	static {
		specialNum=10000;
	}
	

	
	public static int getSpecialNum() {
		return specialNum;
	}
	public static void setSpecialNum(int specialNum) {
		Goods.specialNum = specialNum;
	}
	public int getGoodsNum() {
		return goodsNum;
	}
	public void setGoodsNum(int goodsNum) {
		this.goodsNum = goodsNum;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public String getGoodsPrice() {
		return goodsPrice;
	}
	public void setGoodsPrice(String goodsPrice) {
		this.goodsPrice = goodsPrice;
	}
	

}
