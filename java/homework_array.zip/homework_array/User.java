package homework_array;

public class User {
	String purchaseName; //구매자
	String totalPrice;	//구매금액
	Purchase purchase;
	
	

	public void showInfo(Purchase purchase) {
		System.out.println(getPurchaseName());
		System.out.println(getTotalPrice());
		System.out.println(purchase.getConfirmNum());
		System.out.println(purchase.getPaymentDate());
		System.out.println(purchase.getCardNum());		
	}
	
	
	
	public Purchase getPurchase() {
		return purchase;
	}

	public void setPurchase(Purchase purchase) {
		this.purchase = purchase;
	}

	public String getPurchaseName() {
		return purchaseName;
	}
	public void setPurchaseName(String purchaseName) {
		this.purchaseName = purchaseName;
	}
	public String getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	
	
	

}
