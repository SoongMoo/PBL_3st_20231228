package homework_array;

public class Mart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//구매정보와 구매 정보에 대한 결제 정보
		
		User user = new User();
		user.setPurchaseName("오기영");
		user.setTotalPrice("10만원");
		
		Purchase purchase1 = new Purchase();
		purchase1.setConfirmNum("1");
		purchase1.setPaymentDate("1월 19일");
		purchase1.setCardNum("1234");
		
		user.showInfo(purchase1);
		
		
		
	}

}
